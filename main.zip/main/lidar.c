#include "lidar.h"

// Function to get distance from LiDAR
int get_distance()
{
    // Obtaining Measurements from the I2C Interface
    // You can obtain measurement results from the I2C interface.
    // 1 Write 0x04 to register 0x00.
    // 2 Read register 0x01.
    // 3 Repeat step 2 until bit 0 (LSB) goes low.
    // 4 Read two bytes from 0x10 (low byte 0x10 then high byte 0x11) to obtain the 16-bit measured distance in centimeters.
    
    write_reg(0x00, 0x04, LiDAR_ADDR);
    int lsb = 1;
    while (lsb)
    {
        uint8_t data = read_reg(0x01, LiDAR_ADDR);
        lsb = data & 1;
    }

    uint8_t data[2];
    data[0] = read_reg(0x10, LiDAR_ADDR);
    data[1] = read_reg(0x11, LiDAR_ADDR);
    // convert to 16-bit integer
    int distance = (data[1] << 8) | data[0];
    
    return distance;
}