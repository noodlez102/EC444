#ifndef LIDAR_H
#define LIDAR_H

#include <stdio.h>
#include "i2c.h"

// LiDAR
#define LiDAR_ADDR 0x62 // LiDAR address found from i2c_scanner

// Function prototypes
int get_distance();

#endif // LIDAR_H