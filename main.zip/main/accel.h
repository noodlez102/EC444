#ifndef ACCEL_H
#define ACCEL_H

#include <stdio.h>
#include <math.h>
#include "ADXL343.h"
#include "i2c.h"

// ADXL343
#define ACCEL_ADDR ADXL343_ADDRESS // 0x53

// Function prototypes
int getDeviceID(uint8_t *data);
int16_t read16(uint8_t reg);
void setRange(range_t range);
range_t getRange(void);
dataRate_t getDataRate(void);
void getAccel(float *xp, float *yp, float *zp);
void calcRP(float x, float y, float z, float *roll, float *pitch);
void accel_init();

#endif // ACCEL_H