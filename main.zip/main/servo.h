#ifndef SERVO_H
#define SERVO_H

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/mcpwm_prelude.h"
#include "esp_log.h"

// servo settings
#define SERVO_MIN_PULSEWIDTH_US_1 500        // Minimum pulse width in microsecond
#define SERVO_MAX_PULSEWIDTH_US_1 2500       // Maximum pulse width in microsecond
#define SERVO_MIN_DEGREE -90                 // Minimum angle
#define SERVO_MAX_DEGREE 90                  // Maximum angle
#define SERVO_TIMEBASE_RESOLUTION_HZ 1000000 // 1MHz, 1us per tick
#define SERVO_TIMEBASE_PERIOD 20000          // 20000 ticks, 20ms
// 1us per tick, 20ms period, 50Hz frequency

// Function prototypes
uint32_t example_angle_to_compare(int angle);
mcpwm_cmpr_handle_t servo_init(int gpio_pin);
void calibration(mcpwm_cmpr_handle_t speed_comparator, mcpwm_cmpr_handle_t steer_comparator);

#endif // SERVO_H

